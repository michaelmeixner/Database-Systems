<html>
    <body>
        <center>
            <h3 style="font-family: Verdana, Geneva, Tahoma, sans-serif; color: darkslategrey; font-weight: lighter">The result of your calculation is:<br></h3>
            <?php
                $first = (double) $_POST['firstDigit'];
                $second = (double) $_POST['secondDigit'];
                $operand = $_POST['operand'];
                if($operand == "add") {
                    echo $first + $second;
                }
                if($operand == "subtract") {
                    echo $first - $second;
                }
                if($operand == "multiply") {
                    echo $first * $second;
                }
                if($operand == "divide") {
                    echo $first / $second;
                }
            ?>
        </center>
    </body>
</html>